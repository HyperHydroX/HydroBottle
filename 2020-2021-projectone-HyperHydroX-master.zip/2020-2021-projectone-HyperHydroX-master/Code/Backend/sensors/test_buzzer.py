from Buzzer import Buzzer
import time

alarm = Buzzer()
alarm.alarm_on()
time.sleep(2)
alarm.alarm_off()
