[connector_python]
user = student
host = 127.0.0.1
port = 3306
password = LordPervert007lol?
database = HydroBottle

[application_config]
driver = 'SQL Server'
